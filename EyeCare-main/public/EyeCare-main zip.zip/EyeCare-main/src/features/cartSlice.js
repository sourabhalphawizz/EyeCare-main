import { createSlice } from "@reduxjs/toolkit";
import Product from "../Product";
const initialState = {
    cart : [],
items : Product,
totalQuantaty:0,
totalPrice : 0,

}


export const cartSlice = createSlice({
    name : 'cart',
    initialState,
    reducers : {
        handleAddToCart: (state,action)=>{
            state.cart.push(action.payload);
        }
    },
}) 
export const  {handleAddToCart} = cartSlice.actions;


export default cartSlice.reducer;
