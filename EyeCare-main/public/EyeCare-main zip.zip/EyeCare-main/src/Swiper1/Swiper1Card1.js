const Swiper1Card1 = ({ title, description }) => {
    return (
      <div className="card">
        <h3>{title}</h3>
        {/* <p>{description}</p> */}
      </div>
    );
  };
  export default Swiper1Card1;
  